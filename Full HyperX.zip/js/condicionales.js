//Condicional para ingreso a la base de datos HyperX
// const userHX = "HyperX" //respetar mayúsculas
// const passHX = "2002" // pw: año de fundacion


// const user = prompt("Ingresa tu usuario");
// const pass = prompt("Ingresa tu contraseña");

// const condicion = user == userHX && pass == passHX;

// if (condicion) {
//     alert("Logueado correctamente")
// } else {
//     alert("Datos erróneos, intentá nuevamente")
// }

